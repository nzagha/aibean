import Link from "next/link";
import { UserButton } from "@clerk/nextjs";
import { eq } from "drizzle-orm";
import { requireUser } from "@/lib/auth";
import { db } from "@/lib/db";
import {
  savedTools,
  tools,
  stacks,
  stackTools,
  reviews,
  claims,
} from "@/lib/db/schema";
import { createStack } from "@/app/actions";
export const dynamic = "force-dynamic";
export const metadata = {
  title: "Your account",
  robots: { index: false, follow: false },
};
export default async function Account() {
  const user = await requireUser();
  const [saved, myStacks, myReviews, myClaims] = await Promise.all([
    db()
      .select({ id: tools.id, name: tools.name, slug: tools.slug })
      .from(savedTools)
      .innerJoin(tools, eq(savedTools.toolId, tools.id))
      .where(eq(savedTools.userId, user.id)),
    db().select().from(stacks).where(eq(stacks.userId, user.id)),
    db().select().from(reviews).where(eq(reviews.userId, user.id)),
    db().select().from(claims).where(eq(claims.userId, user.id)),
  ]);
  const members = await db()
    .select({ stackId: stackTools.stackId, name: tools.name, slug: tools.slug })
    .from(stackTools)
    .innerJoin(stacks, eq(stackTools.stackId, stacks.id))
    .innerJoin(tools, eq(stackTools.toolId, tools.id))
    .where(eq(stacks.userId, user.id));
  return (
    <div className="container py-16">
      <div className="flex justify-between">
        <span className="eyebrow">Your aiBean</span>
        <UserButton />
      </div>
      <h1 className="my-6 font-display text-5xl font-bold">Your next moves.</h1>
      <div className="flex flex-wrap gap-5 mb-8">
        <Link href="/featured/manage" className="text-link">
          Featured placements →
        </Link>
        <Link href="/vendor" className="text-link">
          Vendor workspace →
        </Link>
        <Link href="/pricing" className="text-link">
          Pricing →
        </Link>
        {user.isAdmin && (
          <Link href="/admin" className="text-link">
            Admin →
          </Link>
        )}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <section id="saved" className="placeholder-card">
          <h2 className="text-2xl">Saved tools</h2>
          {saved.length ? (
            saved.map((t) => (
              <Link
                className="account-row"
                key={t.id}
                href={`/tools/${t.slug}`}
              >
                {t.name} →
              </Link>
            ))
          ) : (
            <p className="mt-5">Your saved tools will appear here.</p>
          )}
        </section>
        <section id="stacks" className="placeholder-card">
          <h2 className="text-2xl">Personal stacks</h2>
          {myStacks.map((s) => (
            <div key={s.id} className="border-b border-line py-4">
              <h3 className="text-lg">{s.name}</h3>
              {members
                .filter((m) => m.stackId === s.id)
                .map((m) => (
                  <Link
                    key={m.slug}
                    className="account-row"
                    href={`/tools/${m.slug}`}
                  >
                    {m.name} →
                  </Link>
                ))}
            </div>
          ))}
          <form action={createStack} className="mt-5">
            <label className="field">
              New stack name
              <input
                name="name"
                required
                minLength={2}
                maxLength={80}
                placeholder="My research stack"
              />
            </label>
            <button className="button primary">Create stack</button>
          </form>
        </section>
        <section id="reviews" className="placeholder-card">
          <h2 className="text-2xl">Your reviews</h2>
          {myReviews.length ? (
            myReviews.map((r) => (
              <div key={r.id} className="account-row">
                <strong>
                  {r.rating} / 5 · {r.status}
                </strong>
                <p>{r.body}</p>
              </div>
            ))
          ) : (
            <p className="mt-5">You haven’t submitted any reviews.</p>
          )}
        </section>
        <section id="claims" className="placeholder-card">
          <h2 className="text-2xl">Claim requests</h2>
          {myClaims.length ? (
            myClaims.map((c) => (
              <p className="account-row" key={c.id}>
                {c.company} · {c.status.replaceAll("_", " ")}
              </p>
            ))
          ) : (
            <p className="mt-5">No claim requests yet.</p>
          )}
        </section>
      </div>
    </div>
  );
}
