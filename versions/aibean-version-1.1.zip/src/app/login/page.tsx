import { AuthPage } from "@/components/auth-page";
export const metadata = {
  title: "Login",
  robots: { index: false, follow: false },
};
export default async function Login({
  searchParams,
}: {
  searchParams: Promise<{ returnTo?: string }>;
}) {
  return <AuthPage returnTo={(await searchParams).returnTo} />;
}
