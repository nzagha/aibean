import "server-only";
import { auth } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { eq } from "drizzle-orm";
import { db } from "./db";
import { users, vendorAccess } from "./db/schema";
import { safeReturnPath } from "./catalog/filter";
export const authConfigured = () =>
  Boolean(
    process.env.NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY &&
    process.env.CLERK_SECRET_KEY,
  );
export async function getIdentity() {
  if (!authConfigured()) return null;
  return (await auth()).userId;
}
export async function requireUser(returnTo = "/account") {
  const id = await getIdentity();
  if (!id)
    redirect(`/login?returnTo=${encodeURIComponent(safeReturnPath(returnTo))}`);
  await db().insert(users).values({ id }).onConflictDoNothing();
  const [user] = await db().select().from(users).where(eq(users.id, id));
  return user;
}
export async function requireAdmin() {
  const user = await requireUser("/admin");
  if (!user.isAdmin) redirect("/account?notice=admin-required");
  return user;
}
export async function requireVendor() {
  const user = await requireUser("/vendor");
  const access = await db()
    .select()
    .from(vendorAccess)
    .where(eq(vendorAccess.userId, user.id));
  return { user, access };
}
