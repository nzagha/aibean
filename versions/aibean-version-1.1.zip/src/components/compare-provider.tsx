"use client";
import Link from "next/link";
import { createContext, useContext, useState, type ReactNode } from "react";
import { X, Columns3 } from "lucide-react";
import { updateComparison } from "@/lib/catalog/filter";
type Item = { id: string; slug: string; name: string };
const CompareContext = createContext<{
  items: Item[];
  toggle: (item: Item) => void;
  clear: () => void;
}>({ items: [], toggle: () => {}, clear: () => {} });
export const useCompare = () => useContext(CompareContext);
export function CompareProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Item[]>([]);
  const [message, setMessage] = useState("");
  function toggle(item: Item) {
    if (!items.some((x) => x.id === item.id) && items.length >= 4) {
      setMessage("Your comparison has 4 tools. Remove one to add another.");
      return;
    }
    setMessage("");
    setItems((current) => {
      const next = updateComparison(
        current.map((x) => x.id),
        item.id,
      );
      return next.map((id) =>
        id === item.id ? item : current.find((x) => x.id === id)!,
      );
    });
  }
  return (
    <CompareContext.Provider
      value={{
        items,
        toggle,
        clear: () => {
          setItems([]);
          setMessage("");
        },
      }}
    >
      {children}
      {items.length > 0 && (
        <aside className="compare-tray" aria-label="Comparison tray">
          <div className="flex flex-wrap items-center gap-3">
            <Columns3 size={20} />
            <strong className="text-sm">Compare {items.length}/4</strong>
            {items.map((item) => (
              <button
                type="button"
                key={item.id}
                onClick={() => toggle(item)}
                className="compare-chip"
                aria-label={`Remove ${item.name} from comparison`}
              >
                {item.name}
                <X size={14} />
              </button>
            ))}
            <button className="text-link" onClick={() => setItems([])}>
              Clear
            </button>
            <Link
              aria-disabled={items.length < 2}
              onClick={(e) => {
                if (items.length < 2) e.preventDefault();
              }}
              href={`/compare?tools=${items.map((x) => x.slug).join(",")}`}
              className="button primary"
            >
              {items.length < 2 ? "Add 1 more tool" : "Compare tools"}
            </Link>
          </div>
          <p className="mt-2 text-xs" role="status">
            {message ||
              "Guest shortlist lasts while you browse. Sign in to save tools to your account."}
          </p>
        </aside>
      )}
    </CompareContext.Provider>
  );
}
export function CompareButton({ tool }: { tool: Item }) {
  const { items, toggle } = useCompare();
  const selected = items.some((x) => x.id === tool.id);
  return (
    <button
      className={`button secondary compare-button ${selected ? "selected" : ""}`}
      aria-pressed={selected}
      onClick={() => toggle(tool)}
    >
      <Columns3 size={16} />
      {selected ? "Added" : "Compare"}
    </button>
  );
}
