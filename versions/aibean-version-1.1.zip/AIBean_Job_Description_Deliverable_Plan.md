# AIBean Platform Development - Job Description & Deliverable Plan

**Position:** Full-Stack Developer / Product Designer (Hybrid)  
**Duration:** 4 weeks (28 days) / Flexible, can extend if needed  
**Type:** Contract / Project-Based  
**Location:** Remote / Flexible  
**Compensation:** Negotiable based on experience ($8,000 - $15,000 USD for full scope)

---

## 📋 About AIBean

AIBean is a sophisticated **AI Knowledge Hub and Discovery Platform** designed to help professionals, researchers, and teams discover, review, compare, and learn about AI tools. The platform serves as a comprehensive resource for:

- **AI Tools Review & Ranking** - Community-driven reviews and intelligent rankings
- **AI Knowledge Base** - Curated articles, tutorials, and best practices
- **Tool Discovery & Filtering** - Smart discovery with category-based icon system
- **Intelligent Comparison** - Side-by-side tool comparisons with detailed specs
- **Educational Content** - Learning resources and tool integration guides

---

## 🎯 Project Overview

We are seeking a talented **Full-Stack Developer** with strong design sensibilities to build the complete AIBean platform from the brand foundation up. This is a rapid, high-impact project that requires both technical excellence and attention to visual/UX detail.

**Scope:** Build a fully functional, beautifully designed, and production-ready platform in 4 weeks.

---

## 🎨 Brand Identity & Visual System (Provided)

The visual identity has been professionally designed and includes:

### Logo & Branding
- **Primary Mark:** Orange circular logo (#FF6B35) with orange accent color
- **Wordmark:** "AIBean" in modern system typography (System UI / -apple-system)
- **Tagline:** "Knowledge Made Clear" / "Clarity Through Icons"
- **Version Badge:** v1.0

### Color Palette
- **Primary Orange:** #FF6B35 (energy, action, discovery)
- **Dark Base:** #1A1A1A (text, primary UI elements)
- **Grays:** #666666, #999999, #CCCCCC, #F5F5F5, #FAFAFA (hierarchy)
- **White:** #FFFFFF (content areas, cards)
- **Background:** #FAFAFA (clean, light canvas)

### Icon System (Provided)
A comprehensive **24px grid-based icon system** with 10+ category icons:
1. **Chatbots** - Speech bubble with dots
2. **Research** - Magnifying glass with search dot
3. **Image Generation** - Frame with grid and dots
4. **Video** - Play button in frame
5. **Automation** - Connected blocks/nodes
6. **Coding** - Code brackets and chevrons
7. **Marketing** - Megaphone/bullhorn
8. **Real Estate** - House icon
9. **Productivity** - Checklist
10. **Agents** - User profile
11. + Additional categories as needed

**Design Principles:**
- Simple, clean shapes for clarity at any size
- Consistent 2px stroke weight across all icons
- Rounded 2px corners for friendliness
- Orange accent used sparingly for highlights/selections
- All icons work in monochrome + orange accent color
- Minimum size: 24px, scales cleanly to 128px+

### Typography System
- **Headlines:** System UI / -apple-system, 600 weight, sizes 24-36px
- **Subheadings:** System UI, 600 weight, 14-18px
- **Body Text:** System UI, 400 weight, 12-14px, #666 color
- **Accent:** Orange (#FF6B35) for interactive elements, CTAs, highlights

### Design Specifications
- **Grid:** 24px modular grid
- **Stroke:** 2px uniform across UI elements
- **Border Radius:** 4px for subtle rounding
- **Spacing:** Consistent 8px/16px/24px intervals
- **Shadow:** Minimal (no heavy shadows, maintain clean aesthetic)
- **Contrast:** WCAG AA compliant (minimum 4.5:1 for text)

---

## 🌐 Website Theme & Architecture

### Design Aesthetic
**Modern, Icon-Driven, Clean, Professional**
- Light background (#FAFAFA) with white content areas
- Heavy emphasis on icon system for navigation and categorization
- Minimal text, maximum visual communication
- Orange accent used strategically for CTAs and guidance
- Card-based layout for tool listings
- Spacious, uncluttered design with strong negative space

### Core Pages & Features

#### 1. **Homepage / Landing Page**
- Hero section with clear value proposition
- Feature highlights (4-6 key benefits with icons)
- Call-to-action buttons (CTA: "Start Exploring")
- Social proof / testimonials section
- Quick category preview
- Newsletter signup
- Footer with links, social media

#### 2. **Discovery / Browse Page** (Primary)
- **Sidebar Navigation:**
  - Search bar (global search)
  - Category filter pills (Chatbots, Research, Image, Video, etc.)
  - Sort options (Newest, Popular, Rating, Free/Paid)
  - Advanced filters (by features, pricing, integration, etc.)

- **Main Content Grid:**
  - Tool cards in responsive grid (3-4 columns on desktop, 1-2 on mobile)
  - Each card shows:
    - Tool name + logo
    - Brief description (2-3 lines)
    - Category icon
    - Rating/review count
    - Price tag (Free/Freemium/Paid)
    - "View Details" button
    - "Add to Comparison" checkbox

- **Filter Pills Section:**
  - Active filters show with clear state indication
  - Orange highlight for active filter
  - Easy clear all option

#### 3. **Tool Detail Page**
- Tool header with logo, name, tagline
- Hero image / screenshot
- **Tabs or sections:**
  - Overview (description, features, use cases)
  - Specifications (pricing, integrations, API, etc.)
  - Reviews & Ratings (community reviews, rating breakdown)
  - Alternatives (similar tools with comparison)
  - Learning Resources (tutorials, docs, integrations)
- Sidebar:
  - Pricing tier selector
  - CTA button ("Visit Website" / "Get Started")
  - Share options
  - "Add to Collection" option

#### 4. **Comparison Page**
- Select 2-5 tools side-by-side
- **Comparison features:**
  - Feature matrix (Pricing, Integrations, Support, Speed, etc.)
  - Ratings comparison
  - Feature availability checklist
  - Pros/Cons summary
  - Pricing breakdown
- Export comparison (PDF, CSV)
- Share comparison link

#### 5. **Collections / Playbooks**
- Curated collections created by team + community
- Examples: "Best AI Writing Tools", "Free ML Tools", "Enterprise AI Solutions"
- Each collection has:
  - Description and category icon
  - Tools listed with icon badges
  - Follow/save option

#### 6. **Knowledge Base / Articles**
- Search and category filter
- Article grid with:
  - Featured image
  - Title
  - Author + date
  - Read time
  - Category/topic tags
- Article detail page with:
  - Full content (rich text/markdown)
  - Related articles
  - Tools mentioned with links
  - Author bio
  - Share options

#### 7. **User Account / Dashboard** (MVP)
- Profile page (name, email, preferences)
- Saved tools collection
- Comparison history
- Preferences (notifications, theme, etc.)
- Logout

#### 8. **Navigation & Header**
- Fixed header with:
  - AIBean logo (left)
  - Main nav: Explore | Knowledge | Collections | [Login/Sign Up]
  - Search icon
  - User menu (if logged in)
- Mobile: Hamburger menu with slide-in navigation

---

## 📱 Technical Requirements

### Frontend
- **Framework:** React.js (or Next.js for SSR/better SEO)
- **Styling:** Tailwind CSS (or CSS Modules)
- **UI Components:** Radix UI or Headless UI
- **State Management:** React Context API or Redux
- **Search/Filter:** Client-side + potential server-side (Algolia optional for advanced search)
- **Responsive:** Mobile-first, fully responsive (mobile, tablet, desktop)
- **Performance:** Optimized for Core Web Vitals (LCP, FID, CLS)

### Backend (Optional MVP)
- **Database:** Supabase, Firebase, or PostgreSQL
- **Auth:** Email/Google OAuth (Supabase Auth or Auth0)
- **API:** REST or GraphQL (Node.js + Express, or Next.js API routes)
- **Storage:** Cloudinary/Supabase for images
- **Hosting:** Vercel, Netlify, or AWS

### Data Structure (Initial/MVP)
```json
{
  "tools": [
    {
      "id": "chatgpt-001",
      "name": "ChatGPT",
      "category": "chatbots",
      "categoryIcon": "chatbot",
      "tagline": "Advanced AI assistant powered by GPT-4",
      "description": "...",
      "logo": "https://...",
      "images": ["..."],
      "rating": 4.8,
      "reviews": 2341,
      "pricing": "Free / $20/month",
      "features": [...],
      "integrations": [...],
      "tags": ["writing", "productivity", "coding"],
      "pros": [...],
      "cons": [...],
      "url": "https://openai.com/chatgpt"
    }
  ],
  "articles": [...],
  "collections": [...]
}
```

### SEO & Analytics
- Meta tags optimization
- Open Graph / Twitter cards
- Sitemap & robots.txt
- Google Analytics 4 integration
- Structured data (Schema.org) for tools
- Fast page load times (Core Web Vitals)

### Accessibility
- WCAG 2.1 AA compliant
- Semantic HTML
- Keyboard navigation throughout
- ARIA labels where needed
- Color contrast verified
- Screen reader tested

---

## 📦 Deliverables Breakdown (4-Week Timeline)

### **Week 1: Foundation & Design System**

#### Deliverables:
1. **Design System Setup**
   - [ ] Tailwind config with AIBean colors, typography, spacing
   - [ ] Reusable component library (Button, Card, Badge, Pill, Modal, etc.)
   - [ ] Icon system integrated (SVG icons for all 10+ categories)
   - [ ] Typography scale tested across browsers

2. **Project Structure**
   - [ ] Git repo initialized with proper structure
   - [ ] Environment variables set up (.env template)
   - [ ] CI/CD pipeline basics (GitHub Actions or similar)
   - [ ] README with setup instructions

3. **Homepage**
   - [ ] Hero section with value proposition
   - [ ] Feature highlights (4 sections with icons)
   - [ ] Call-to-action buttons
   - [ ] Feature section layout
   - [ ] Testimonials/social proof section
   - [ ] Newsletter signup form
   - [ ] Footer with links and social

4. **Navigation & Layout**
   - [ ] Header component (fixed, responsive)
   - [ ] Footer component
   - [ ] Mobile menu (hamburger)
   - [ ] Breadcrumb navigation
   - [ ] Layout system (containers, responsive grid)

**Success Criteria:** Homepage is pixel-perfect to design specs, mobile-responsive, all colors/typography correct, CI/CD working.

---

### **Week 2: Core Discovery & Browsing Features**

#### Deliverables:

1. **Browse/Discover Page**
   - [ ] Tool grid layout (responsive, 3-4 columns desktop)
   - [ ] Tool cards with all required fields (name, icon, rating, price, description)
   - [ ] Hover states and interactions (smooth transitions)
   - [ ] "Add to Comparison" checkboxes on cards
   - [ ] View Details button linking to tool page

2. **Sidebar Navigation & Filters**
   - [ ] Search bar (functional, debounced)
   - [ ] Category filter pills (all 10+ categories)
   - [ ] Sort dropdown (Newest, Popular, Rating, Price)
   - [ ] Additional filters (Free/Paid toggle, integrations)
   - [ ] Filter state persistence (URL params or local storage)
   - [ ] "Clear all filters" button

3. **Data Integration**
   - [ ] Sample dataset of 20-30 AI tools (or hook into backend API)
   - [ ] Tool data structure finalized
   - [ ] Search functionality (client-side filtering, can upgrade to Algolia later)
   - [ ] Filter logic working correctly

4. **User Interaction States**
   - [ ] Active filter highlighting (orange accent)
   - [ ] Loading states on cards
   - [ ] Empty state (no results)
   - [ ] Animations/transitions smooth

**Success Criteria:** Full filtering/search working, all icons rendering correctly, responsive on all devices, fast load times, no layout shifts.

---

### **Week 3: Tool Details, Comparisons & Content Pages**

#### Deliverables:

1. **Tool Detail Page**
   - [ ] Tool header (logo, name, tagline, quick stats)
   - [ ] Hero image section
   - [ ] Navigation tabs (Overview, Specifications, Reviews, Alternatives)
   - [ ] Overview section (description, key features, use cases)
   - [ ] Specifications section (pricing, integrations, API, languages)
   - [ ] Reviews section (star rating, sample reviews)
   - [ ] Alternatives section (similar tools with comparison)
   - [ ] Sidebar (pricing, CTA, share buttons, save to collection)
   - [ ] Related/recommended tools section

2. **Comparison Page**
   - [ ] Comparison selector (add 2-5 tools)
   - [ ] Feature matrix table (responsive on mobile)
   - [ ] Pricing comparison
   - [ ] Feature checklist
   - [ ] Pros/Cons summary per tool
   - [ ] Export options (PDF, CSV - basic implementation)
   - [ ] Share comparison link

3. **Collections / Playbooks Page**
   - [ ] Collection grid layout
   - [ ] Each collection shows (name, icon, description, tool count)
   - [ ] Click to view collection details
   - [ ] Display tools within a collection
   - [ ] Save/follow collection option

4. **Knowledge Base / Articles Page**
   - [ ] Article grid with preview cards
   - [ ] Search and category filter
   - [ ] Article detail page with full content
   - [ ] Author bio section
   - [ ] Related articles suggestions
   - [ ] Share buttons

**Success Criteria:** All pages routing correctly, data flowing properly, no broken links, responsive design maintained, icons consistent throughout.

---

### **Week 4: Authentication, Polish & Launch Prep**

#### Deliverables:

1. **User Authentication (Basic MVP)**
   - [ ] Sign-up form (email)
   - [ ] Login form
   - [ ] Password reset flow (basic)
   - [ ] User profile page
   - [ ] Logout functionality
   - [ ] Protected routes (if needed for collections/saved tools)

2. **User Features**
   - [ ] Saved tools / collections (localStorage or backend)
   - [ ] Comparison history
   - [ ] User preferences (email notifications opt-in)
   - [ ] User dashboard

3. **Performance & Optimization**
   - [ ] Image optimization (Cloudinary or next/image)
   - [ ] Code splitting & lazy loading
   - [ ] SEO optimization (meta tags, sitemap)
   - [ ] Core Web Vitals audit (LCP < 2.5s, FID < 100ms, CLS < 0.1)
   - [ ] Lighthouse score > 90

4. **Testing & QA**
   - [ ] Cross-browser testing (Chrome, Safari, Firefox, Edge)
   - [ ] Mobile testing (iOS, Android)
   - [ ] Accessibility testing (keyboard nav, screen reader)
   - [ ] Performance testing (Lighthouse, GTmetrix)
   - [ ] Bug fixes and polish

5. **Documentation & Deployment**
   - [ ] API documentation (if backend built)
   - [ ] Setup/deployment instructions
   - [ ] Code comments where needed
   - [ ] Known issues / tech debt documented
   - [ ] Deploy to production (Vercel, Netlify, or AWS)
   - [ ] DNS/domain setup
   - [ ] SSL certificate
   - [ ] Analytics set up

6. **Final Polish & Brand Compliance**
   - [ ] Visual audit against brand guidelines
   - [ ] Typography audit (correct sizes, weights, colors)
   - [ ] Icon system verification (all icons rendering correctly)
   - [ ] Color palette verification (all specs colors used correctly)
   - [ ] Animation/transition consistency
   - [ ] Micro-interactions feel polished
   - [ ] Error messages are helpful
   - [ ] Loading states are clear
   - [ ] Success messages are positive

**Success Criteria:** Production-ready site, zero critical bugs, all brand requirements met, fully accessible, fast loading, documented, deployed.

---

## 💼 Required Skills & Experience

### Essential
- **Frontend Development:** 3+ years React, Next.js, or similar modern framework
- **CSS/Styling:** Expert in Tailwind CSS, CSS-in-JS, or equivalent
- **Responsive Design:** Mobile-first, cross-browser testing
- **JavaScript/TypeScript:** Strong ES6+, async patterns, error handling
- **Git/Version Control:** Proficient with GitHub/GitLab
- **API Integration:** Comfortable working with REST APIs
- **Performance:** Understanding of Core Web Vitals, optimization techniques

### Highly Desirable
- Next.js experience (for SSR, SEO benefits)
- Experience with design systems / component libraries
- Icon system implementation (SVG handling)
- Figma → Code experience
- E-commerce or SaaS product experience
- SEO best practices knowledge
- Accessibility (WCAG) compliance
- Docker / containerization basics

### Nice to Have
- Supabase or Firebase experience
- GraphQL experience
- Vercel deployment experience
- Analytics integration (GA4, Mixpanel)
- Open source contributions
- Design eye (attention to detail, layout sense)

---

## 🎯 Success Metrics

At project completion, the platform should have:

✅ **Functionality**
- All pages loading without errors
- Search and filtering working smoothly
- Comparison feature fully functional
- Mobile-responsive across all screen sizes
- Authentication working (if included)

✅ **Performance**
- Lighthouse score ≥ 90
- Core Web Vitals all green
- Page load < 2.5 seconds
- No layout shift during load

✅ **Design Quality**
- Brand identity 100% consistent
- All colors, typography, spacing per specs
- Icon system correctly implemented
- Micro-interactions smooth and delightful
- Hover states, focus states clear

✅ **Code Quality**
- Clean, readable, well-organized code
- Proper component structure
- No console errors/warnings
- Accessible (WCAG AA minimum)
- SEO-optimized

✅ **Documentation**
- Clear README with setup instructions
- Comments on complex logic
- API docs (if backend)
- Known issues documented
- Easy handoff to maintenance team

---

## 📅 Timeline & Milestones

| Week | Milestone | Deliverables |
|------|-----------|--------------|
| **Week 1** | Foundation Complete | Design system, homepage, navigation |
| **Week 2** | Discovery Ready | Browse page, filters, search, 20+ tools |
| **Week 3** | Full Content | Tool details, comparisons, articles, collections |
| **Week 4** | Launch Ready | Auth, polish, deployment, documentation |

**Daily Standup:** Brief async updates (Slack/email) on progress, blockers, next day's plan  
**Mid-week Check-in:** 30-min sync call (Wed) to review progress and adjust if needed  
**Week-end Review:** Friday demo of completed deliverables  

---

## 💰 Budget & Compensation

**Suggested Budget:** $8,000 - $15,000 USD (depending on experience level)

- **Junior Dev (1-3 yrs):** $8,000 - $10,000
- **Mid-level Dev (3-5 yrs):** $10,000 - $12,000
- **Senior Dev (5+ yrs):** $12,000 - $15,000

**Payment Structure:**
- 25% deposit upon contract signing
- 25% at end of Week 1 (foundation complete)
- 25% at end of Week 3 (core features complete)
- 25% upon final deployment + handoff

---

## 📝 Application Instructions

### To Apply, Please Provide:

1. **Your Portfolio**
   - 2-3 recent projects demonstrating React/Next.js skills
   - Links to deployed sites
   - GitHub repos (if available)

2. **Experience Summary**
   - Years of professional development
   - Relevant project examples (SaaS, platforms, design systems)
   - Any open source contributions

3. **Design System Experience**
   - Have you built or implemented design systems?
   - Component library work examples?
   - Tailwind CSS experience level?

4. **Availability & Timeline**
   - Can you commit to 4 weeks, starting [DATE]?
   - Estimated hours per week?
   - Time zone?
   - Any potential blockers?

5. **Questions for Us**
   - Any clarifications needed?
   - Suggested tech stack modifications?
   - Timeline or scope adjustments?

### Submission
Email your application to: **[hiring@aibean.io]**  
Subject: "AIBean Platform Developer - [Your Name]"

---

## ❓ FAQ

**Q: Is this a full-time commitment?**  
A: Yes, ideally 40+ hours/week for 4 weeks to complete the scope. Flexible on daily schedule as long as deadlines are met.

**Q: Can I modify the tech stack?**  
A: Open to discussion if alternatives are justified and deliver equivalent/better results. Core requirement: React or React-adjacent.

**Q: What if I can't complete everything in 4 weeks?**  
A: We can scope down to MVP (just Discovery page + tool details + homepage) or extend timeline by 1-2 weeks (budget adjustment).

**Q: Will I get design files?**  
A: Yes, brand guidelines and component specs provided. Figma file available for reference.

**Q: What about ongoing maintenance?**  
A: This project is for initial build. Separate contract for maintenance/updates can be discussed.

**Q: Can I start before [DATE]?**  
A: Yes! Early start is welcome and appreciated.

---

## 🤝 Contact & Questions

**Hiring Manager:** [Your Name]  
**Email:** [Your Email]  
**Phone:** [Your Phone]  

**Brand Assets Provided:**
- Brand guidelines document (colors, typography, spacing, icons)
- Icon system library (SVG files for all categories)
- Logo files (PNG, SVG, various sizes)
- Design reference images (brand kit boards)

---

**Ready to build something amazing? Apply now! 🚀**

---

*AIBean is committed to building an inclusive, welcoming team. We encourage applications from people of all backgrounds and experience levels.*
