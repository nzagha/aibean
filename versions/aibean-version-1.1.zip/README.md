# aiBean MVP — Stage 1

## Saved design and tool logos

The approved brand/layout baseline is preserved in `versions/aibean-version-1.zip`, with a checksum manifest and restore notes alongside it. The working project adds distinct local SVG logos for all six fictional tools, consistently used in directory/industry cards, featured cards, tool details and comparisons. These are original demo marks, not logos of real businesses. An optional `logoUrl` field supports approved HTTPS image URLs or local `/tool-logos/` assets for real catalog entries; missing or failed images fall back to initials without changing card dimensions.

Featured AI Tools is available on the homepage with the owner-approved offer of **$99 USD for five days**, admin review before payment, and payment-confirmed activation. See `docs/FEATURED_PLACEMENTS.md` for setup and remaining live-service requirements. Test checkout requires `STRIPE_FEATURED_PRICE_ID`; live payments are still disabled.

The approved aiBean branding is retained. Functional authority is the September 30, 2026 MVP Development Master Plan v0.3. The user selected a staged implementation on October 5, 2026.

## Preview without service accounts

Requires Node.js 24 (Node 20.9+ supported by Next.js).

```sh
npm ci
npm run dev
```

Open http://127.0.0.1:3000. Without a database, development mode displays six clearly labeled fictional tools. No real reviews, prices, verification, events, or creator identities are invented. Authentication and charging do not silently run in a fake mode.

The new navigation, scoped search, tool filters/detail pages, industry pages and 2–4 tool comparison are usable. Skills, Playbooks, Events and Creators have clearly labeled later-stage landing pages. Legacy Explore/Knowledge/Collections URLs continue to redirect. The newsletter remains a demo form.

## Local PostgreSQL

Docker Desktop must be running. Copy .env.example to .env.local; choose a local database password and use the same value in DATABASE_URL. Do not paste secrets into chat or commit them.

```sh
npm run db:up
npm run db:migrate
npm run db:seed
npm run dev
```

Postgres uses localhost:54329; Redis uses localhost:63799. No existing containers are deleted. The database persists in a named volume. Seed is idempotent and preserves existing records. Fictional tools are seeded only when AIBEAN_DEMO_MODE=true. Turn this off and curate real tool records before launch.

For the optional Docker app container, run `docker compose --env-file .env.local --profile app up --build`. It is a local development image, served at localhost:3001. Update NEXT_PUBLIC_APP_URL to match when testing billing there. A production image/deployment is a later launch task.

## Enable accounts

Create a Clerk application and configure Google, Apple and email providers. Add NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY and CLERK_SECRET_KEY to .env.local and restart. Google/Apple availability depends on the provider settings; Apple needs its own developer configuration.

Create your own signed-in user. To bootstrap an administrator, run `npm run admin:grant -- user_<your verified Clerk user ID>`. This is an explicit operator action, writes audit history and never exposes an admin signup option. Normal users can save tools, create stacks and submit reviews; administrators can create drafts, publish/archive tools and moderate reviews/paid claims.

Reference: https://clerk.com/docs/nextjs/getting-started/quickstart

## Test-only claim payments

After database and accounts work, create a Stripe test application/price. Set STRIPE_SECRET_KEY (sk_test only), STRIPE_WEBHOOK_SECRET and STRIPE_CLAIM_PRICE_ID (a fixed one-time test Price). Forward signed events to /api/billing/webhook.

The server owns amount/currency and verifies webhook signatures, order/session identity and paid status. Webhooks deduplicate in a database transaction. Only an independent admin review grants one-owner Vendor capability. No claim can award aiBean Verified or ranking benefits. Demo tools cannot be claimed. Add a real curated tool through Admin for a test journey.

Live Stripe keys are intentionally rejected. Refunds/disputes, abandoned checkout recovery, subscriptions and paid submission/edit/verification workflows are not complete. No live payments should be enabled before Stage 2 and launch security gates.

Reference: https://docs.stripe.com/checkout/fulfillment

## Taxonomy

Imported from the supplied aiBean_Taxonomy_Package_v1 (1).xlsx: 25 categories, 202 subcategories, 18 industries, 40 source use cases and 16 listing types. Source IDs/checksum are retained in src/data/taxonomy.json. The source remains unchanged.

UC-035 (community discussions) and excluded listing-type modules are inactive under v0.3. The workbook is v1 and has no standalone sub-vertical records; no v1.1 coverage is asserted. Re-import with scripts/import_taxonomy.py using the bundled Python/openpyxl runtime and the workbook path. Rerun tests after any taxonomy changes.

## Validation

```sh
npm test
npm run typecheck
npm run build
node scripts/smoke-http.mjs
```

The HTTP smoke script expects the unconfigured local development preview (no auth/billing keys). Unit/database tests cover taxonomy relationships, combined filtering, industry fit, trust/freshness, comparison limits, ranking commercial exclusion, URL validation, relational uniqueness and rollback. Database tests use isolated PGlite; they do not imply a connected PostgreSQL deployment has been verified.

During this implementation, Docker Desktop's engine did not respond and the browser automation runtime failed to initialize. PostgreSQL/Clerk/Stripe end-to-end journeys and visual/mobile interaction QA therefore remain pending. The production build and automated domain/migration checks were run. Runtime dependency audit was clean; drizzle-kit currently brings moderate development-only transitive audit advisories. Do not apply an unreviewed forced downgrade to silence them.

## Implementation and next stages

See docs/MVP_SCOPE.md for the staged plan and docs/MVP_ACCEPTANCE_MATRIX.md for what is implemented versus verified or pending. Other contracts cover auth, security, data, ranking, billing, vendor workflows, Skills, Playbooks, Creators and Events.

Current schema uses a typed Tool JSONB payload plus relational category, identity, ownership, engagement, reviews, billing and audit records. Normalize the remaining taxonomy/content/ranking relations before expanding publishing workflows. Search is server-side filtering of the small initial catalog; indexed PostgreSQL search and pagination are required before scaling.

Original supplied logo, illustration and Satoshi/Inter/Caveat fonts stay self-hosted in public/brand. No deployment, service-account creation, live billing, real marketing signup, or production launch is performed by this stage.
